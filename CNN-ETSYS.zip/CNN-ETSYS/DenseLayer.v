module DenseLayer #(parameter INPUT_SIZE=676, parameter OUTPUT_SIZE=32, parameter IS_OUTPUT=0)
(
    input clk, rst, start, input [3:0] shift_val,   
    output reg [9:0] in_addr, input signed [7:0] in_data, 
    output reg [14:0] w_addr, input signed [7:0] w_data,  
    output reg [4:0] b_addr, input signed [15:0] b_data, 
    output reg [4:0] out_addr, output reg signed [31:0] out_data, 
    output reg out_we, output reg done               
);
    localparam S_IDLE=0, S_LOAD_BIAS=1, S_REQ_DATA=2, S_WAIT_DATA=3, S_MAC=4, S_WRITE=5;  
    reg [2:0] state; reg [9:0] n_cnt; reg [4:0] k_cnt; reg signed [31:0] acc;

    wire signed [31:0] val_after_relu = (acc < 0) ? 32'sd0 : acc;
    wire signed [31:0] val_shifted = val_after_relu >>> shift_val;
    wire signed [31:0] val_clamped = (val_shifted > 32'sd127) ? 32'sd127 : val_shifted;
    wire signed [8:0] in_signed = {1'b0, in_data};

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; done <= 0; out_we <= 0; in_addr <= 0; w_addr <= 0; b_addr <= 0;
            out_addr <= 0; out_data <= 0; acc <= 0; n_cnt <= 0; k_cnt <= 0;
        end else begin
            case (state)
                S_IDLE: begin done <= 0; out_we <= 0; if (start) begin k_cnt <= 0; state <= S_LOAD_BIAS; end end
                S_LOAD_BIAS: begin b_addr <= k_cnt; n_cnt <= 0; state <= S_REQ_DATA; end
                S_REQ_DATA: begin
                    in_addr <= n_cnt;
                    // KRITIK: Keras w_addr eslesmesi [in_features, out_features]
                    w_addr  <= (n_cnt * OUTPUT_SIZE) + k_cnt;
                    if (n_cnt == 0) acc <= {{16{b_data[15]}}, b_data};
                    state <= S_WAIT_DATA;
                end
                S_WAIT_DATA: state <= S_MAC;
                S_MAC: begin
                    acc <= acc + (in_signed * w_data);
                    if (n_cnt == INPUT_SIZE - 1) state <= S_WRITE;
                    else begin n_cnt <= n_cnt + 1; state <= S_REQ_DATA; end
                end
                S_WRITE: begin
                    out_addr <= k_cnt; out_we <= 1'b1;
                    if (IS_OUTPUT) out_data <= acc; else out_data <= val_clamped;
                    if (k_cnt == OUTPUT_SIZE - 1) begin done <= 1'b1; state <= S_IDLE; end 
                    else begin k_cnt <= k_cnt + 1; state <= S_LOAD_BIAS; end
                end
                default: state <= S_IDLE;
            endcase
            if (state != S_WRITE) out_we <= 1'b0;
        end
    end
endmodule