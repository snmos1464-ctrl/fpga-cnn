module Conv2D (
    input clk, rst, start,
    output reg [9:0] img_addr, input [7:0] img_data, 
    output reg [5:0] w_addr, input signed [7:0] w_data, 
    output reg [1:0] b_addr, input signed [15:0] b_data,
    output reg [11:0] out_addr, output reg [1:0] out_ch, output reg signed [31:0] out_data, 
    output reg out_we, output reg done
);
    localparam IMG_W = 28, OUT_W = 26;
    localparam S_IDLE=0, S_ADDR=1, S_MAC=2, S_WRITE=3;
    reg [1:0] state;
    reg [4:0] r, c; reg [1:0] f, kr, kc; reg signed [31:0] acc;

    wire signed [8:0] img_signed; assign img_signed = {1'b0, img_data};

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; r <= 0; c <= 0; f <= 0; kr <= 0; kc <= 0; acc <= 0;
            out_we <= 0; done <= 0; out_addr <= 0; out_ch <= 0; out_data <= 0;
            img_addr <= 0; w_addr <= 0; b_addr <= 0;
        end else begin
            case (state)
                S_IDLE: begin
                    r <= 0; c <= 0; f <= 0; kr <= 0; kc <= 0; acc <= 0; done <= 0; out_we <= 0;
                    if (start) state <= S_ADDR;
                end
                S_ADDR: begin
                    img_addr <= (r + kr) * IMG_W + (c + kc);
                    // KRITIK: Keras w_addr e?le?mesi (kr, kc, in_ch, out_ch)
                    w_addr   <= (kr * 12) + (kc * 4) + f; 
                    b_addr   <= f;
                    state <= S_MAC;
                end
                S_MAC: begin
                    acc <= acc + (img_signed * w_data);
                    if (kc == 2) begin
                        kc <= 0;
                        if (kr == 2) begin kr <= 0; state <= S_WRITE; end 
                        else begin kr <= kr + 1; state <= S_ADDR; end
                    end else begin kc <= kc + 1; state <= S_ADDR; end
                end
                S_WRITE: begin
                    if ((acc + b_data) < 0) out_data <= 32'd0;
                    else out_data <= acc + b_data;
                        
                    out_addr <= r * OUT_W + c; out_ch <= f; out_we <= 1'b1; acc <= 32'd0;
                    
                    if (c == OUT_W-1) begin
                        c <= 0;
                        if (r == OUT_W-1) begin
                            r <= 0;
                            if (f == 3) begin done <= 1'b1; state <= S_IDLE; end 
                            else begin f <= f + 1; state <= S_ADDR; end
                        end else begin r <= r + 1; state <= S_ADDR; end
                    end else begin c <= c + 1; state <= S_ADDR; end
                end
            endcase
            if (state != S_WRITE) out_we <= 1'b0;
        end
    end
endmodule