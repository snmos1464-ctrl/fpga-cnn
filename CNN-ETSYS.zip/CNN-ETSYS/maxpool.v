module standalone_maxpool(
    input clk, rst, start,
    output reg [11:0] rd_addr, input signed [31:0] rd_data,
    output reg [11:0] wr_addr, output reg signed [31:0] wr_data,
    output reg wr_en, output reg done
);
    localparam S_IDLE=0, S_READ_0=1, S_WAIT_0=2, S_COMP_0=3, S_WAIT_1=4, S_COMP_1=5, S_WAIT_2=6, S_COMP_2=7, S_WAIT_3=8, S_COMP_3=9, S_WRITE=10;
    reg [3:0] state; reg [4:0] r, c; reg [1:0] ch; reg signed [31:0] max_val;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; r <= 0; c <= 0; ch <= 0; done <= 0; wr_en <= 0;
            rd_addr <= 0; wr_addr <= 0; wr_data <= 0; max_val <= 0;
        end else begin
            case (state)
                S_IDLE: begin
                    done <= 0; wr_en <= 0; r <= 0; c <= 0; ch <= 0;
                    if (start) state <= S_READ_0;
                end
                S_READ_0: begin
                    // NHWC okuma hesaplamasi
                    rd_addr <= ((r * 2) * 104) + ((c * 2) * 4) + ch;
                    wr_en <= 0; state <= S_WAIT_0;
                end
                S_WAIT_0: state <= S_COMP_0;
                S_COMP_0: begin
                    max_val <= rd_data;
                    rd_addr <= ((r * 2) * 104) + ((c * 2 + 1) * 4) + ch;
                    state <= S_WAIT_1;
                end
                S_WAIT_1: state <= S_COMP_1;
                S_COMP_1: begin
                    if (rd_data > max_val) max_val <= rd_data;
                    rd_addr <= ((r * 2 + 1) * 104) + ((c * 2) * 4) + ch;
                    state <= S_WAIT_2;
                end
                S_WAIT_2: state <= S_COMP_2;
                S_COMP_2: begin
                    if (rd_data > max_val) max_val <= rd_data;
                    rd_addr <= ((r * 2 + 1) * 104) + ((c * 2 + 1) * 4) + ch;
                    state <= S_WAIT_3;
                end
                S_WAIT_3: state <= S_COMP_3;
                S_COMP_3: begin
                    if (rd_data > max_val) wr_data <= rd_data; else wr_data <= max_val;
                    // NHWC yazma hesaplamasi
                    wr_addr <= (r * 52) + (c * 4) + ch;
                    wr_en <= 1; state <= S_WRITE;
                end
                S_WRITE: begin
                    wr_en <= 0;
                    if (c == 12) begin
                        c <= 0;
                        if (r == 12) begin
                            r <= 0;
                            if (ch == 3) begin state <= S_IDLE; done <= 1; end 
                            else begin ch <= ch + 1; state <= S_READ_0; end
                        end else begin r <= r + 1; state <= S_READ_0; end
                    end else begin c <= c + 1; state <= S_READ_0; end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule