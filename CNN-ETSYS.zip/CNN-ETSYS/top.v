module top (
    input  wire clk,
    input  wire rst,
    input  wire start,
    output wire [6:0] seg, 
    output wire [3:0] an,
    output wire [15:0] led
);

    reg [6:0] clk_cnt = 0;
    reg slow_clk_reg = 0;
    always @(posedge clk) begin
        if (clk_cnt == 49) begin
            clk_cnt <= 0;
            slow_clk_reg <= ~slow_clk_reg;
        end else clk_cnt <= clk_cnt + 1;
    end
    
    wire slow_clk;
    BUFG clk_bufg (.I(slow_clk_reg), .O(slow_clk));

    reg rst_sync1, rst_sync2;
    reg start_sync1, start_sync2;
    always @(posedge slow_clk) begin
        rst_sync1 <= rst; rst_sync2 <= rst_sync1;
        start_sync1 <= start; start_sync2 <= start_sync1;
    end
    wire sys_rst = rst_sync2;
    wire sys_start = start_sync2;

    localparam S_IDLE=0, S_CONV=1, S_POOL=2, S_FLAT=3, S_D1=4, S_D2=5, S_OUT=6, S_ARG=7, S_DONE=8;
    reg [3:0] state;

    (* ram_style = "distributed" *) reg signed [31:0] ram_conv_out [0:2703];
    (* ram_style = "distributed" *) reg signed [31:0] ram_pool_out [0:675];
    (* ram_style = "distributed" *) reg signed [7:0]  ram_flat [0:675];
    (* ram_style = "distributed" *) reg signed [7:0]  ram_d1_out [0:31];
    (* ram_style = "distributed" *) reg signed [7:0]  ram_d2_out [0:31];
    (* ram_style = "distributed" *) reg signed [31:0] ram_final_scores [0:9];

    (* ram_style = "distributed" *) reg [7:0] rom_image [0:783];
    (* ram_style = "distributed" *) reg signed [7:0]  w_conv [0:35];
    (* ram_style = "distributed" *) reg signed [15:0] b_conv [0:3];
    reg signed [7:0]  w_d1 [0:21631]; 
    (* ram_style = "distributed" *) reg signed [15:0] b_d1 [0:31];
    (* ram_style = "distributed" *) reg signed [7:0]  w_d2 [0:1023];
    (* ram_style = "distributed" *) reg signed [15:0] b_d2 [0:31];
    (* ram_style = "distributed" *) reg signed [7:0]  w_out [0:319];
    (* ram_style = "distributed" *) reg signed [15:0] b_out [0:9];

    initial begin
        $readmemh("test_image_9_label_9_hex.txt", rom_image); 
        $readmemh("conv1_weights_hex.txt", w_conv);
        $readmemh("conv1_bias_hex.txt", b_conv);
        $readmemh("dense1_weights_hex.txt", w_d1);
        $readmemh("dense1_bias_hex.txt", b_d1);
        $readmemh("dense2_weights_hex.txt", w_d2);
        $readmemh("dense2_bias_hex.txt", b_d2); 
        $readmemh("output_weights_hex.txt", w_out);
        $readmemh("output_bias_hex.txt", b_out);
    end

    wire [9:0] img_addr; wire [5:0] c_w_addr; wire [1:0] c_b_addr;
    wire [11:0] c_out_addr; wire [1:0] c_out_ch; wire signed [31:0] c_out_data; wire c_we, done_conv;

    Conv2D conv_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_CONV),
        .img_addr(img_addr), .img_data(rom_image[img_addr]),
        .w_addr(c_w_addr), .w_data(w_conv[c_w_addr]),
        .b_addr(c_b_addr), .b_data(b_conv[c_b_addr]),
        .out_addr(c_out_addr), .out_ch(c_out_ch), .out_data(c_out_data), .out_we(c_we), .done(done_conv)
    );

    // KRITIK: Keras format?na g�re bellek adreslemesi (NHWC)
    always @(posedge slow_clk) if (c_we) ram_conv_out[ (c_out_addr * 4) + c_out_ch ] <= c_out_data;

    wire [11:0] mp_rd_addr, mp_wr_addr; wire signed [31:0] mp_wr_data; wire mp_we, done_pool;

    standalone_maxpool pool_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_POOL),
        .rd_addr(mp_rd_addr), .rd_data(ram_conv_out[mp_rd_addr]),
        .wr_addr(mp_wr_addr), .wr_data(mp_wr_data), .wr_en(mp_we), .done(done_pool)
    );
    always @(posedge slow_clk) if (mp_we) ram_pool_out[mp_wr_addr] <= mp_wr_data;

    wire [7:0] f_data; wire [9:0] f_wr_addr; wire [9:0] f_rd_addr; wire f_we, done_flat;

    Flatten_Quantizer flat_unit (
        .clk(slow_clk), .rst_n(!sys_rst), .start(state == S_FLAT),
        .rd_addr(f_rd_addr), .data_in(ram_pool_out[f_rd_addr]),
        .shift_val(4'd8), .data_out(f_data), .addr_out(f_wr_addr), .we_out(f_we), .done(done_flat)
    );
    always @(posedge slow_clk) if (f_we) ram_flat[f_wr_addr] <= f_data;

    wire [9:0] d1_in_addr; wire [14:0] d1_w_addr; wire [4:0] d1_b_addr, d1_out_addr;
    wire signed [31:0] d1_out_data; wire d1_we, done_d1;

    DenseLayer #(676, 32, 0) d1_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_D1), .shift_val(4'd9),
        .in_addr(d1_in_addr), .in_data(ram_flat[d1_in_addr]),
        .w_addr(d1_w_addr), .w_data(w_d1[d1_w_addr]), .b_addr(d1_b_addr), .b_data(b_d1[d1_b_addr]),
        .out_addr(d1_out_addr), .out_data(d1_out_data), .out_we(d1_we), .done(done_d1)
    );
    always @(posedge slow_clk) if (d1_we) ram_d1_out[d1_out_addr] <= d1_out_data[7:0];

    wire [9:0] d2_in_addr; wire [4:0] d2_b_addr, d2_out_addr; wire [14:0] d2_w_addr;
    wire signed [31:0] d2_out_data; wire d2_we, done_d2;

    DenseLayer #(32, 32, 0) d2_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_D2), .shift_val(4'd8),
        .in_addr(d2_in_addr), .in_data(ram_d1_out[d2_in_addr]), 
        .w_addr(d2_w_addr), .w_data(w_d2[d2_w_addr]), .b_addr(d2_b_addr), .b_data(b_d2[d2_b_addr]),
        .out_addr(d2_out_addr), .out_data(d2_out_data), .out_we(d2_we), .done(done_d2)
    );
    always @(posedge slow_clk) if (d2_we) ram_d2_out[d2_out_addr] <= d2_out_data[7:0];

    wire [9:0] out_in_addr; wire [4:0] out_b_addr, out_out_addr; wire [14:0] out_w_addr;
    wire signed [31:0] out_out_data; wire out_we, done_out;

    DenseLayer #(32, 10, 1) final_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_OUT), .shift_val(4'd0),
        .in_addr(out_in_addr), .in_data(ram_d2_out[out_in_addr]),
        .w_addr(out_w_addr), .w_data(w_out[out_w_addr]), .b_addr(out_b_addr), .b_data(b_out[out_b_addr]),
        .out_addr(out_out_addr), .out_data(out_out_data), .out_we(out_we), .done(done_out)
    );
    always @(posedge slow_clk) if (out_we) ram_final_scores[out_out_addr] <= out_out_data;

    wire [3:0] arg_rd_addr, final_result; wire done_arg;

    Argmax arg_unit (
        .clk(slow_clk), .rst(sys_rst), .start(state == S_ARG),
        .rd_addr(arg_rd_addr), .rd_data(ram_final_scores[arg_rd_addr]),
        .result(final_result), .done(done_arg)
    );

    always @(posedge slow_clk or posedge sys_rst) begin
        if (sys_rst) state <= S_IDLE;
        else begin
            case (state)
                S_IDLE: if (sys_start) state <= S_CONV;
                S_CONV: if (done_conv) state <= S_POOL;
                S_POOL: if (done_pool) state <= S_FLAT;
                S_FLAT: if (done_flat) state <= S_D1;
                S_D1:   if (done_d1)   state <= S_D2;
                S_D2:   if (done_d2)   state <= S_OUT;
                S_OUT:  if (done_out)  state <= S_ARG;
                S_ARG:  if (done_arg)  state <= S_DONE;
                S_DONE: state <= S_DONE;
                default: state <= S_IDLE;
            endcase
        end
    end

    assign an = 4'b1110;
    reg [6:0] s_reg;
    always @(*) begin
        case(final_result)
            4'd0: s_reg = 7'b1000000; 4'd1: s_reg = 7'b1111001; 4'd2: s_reg = 7'b0100100;
            4'd3: s_reg = 7'b0110000; 4'd4: s_reg = 7'b0011001; 4'd5: s_reg = 7'b0010010;
            4'd6: s_reg = 7'b0000010; 4'd7: s_reg = 7'b1111000; 4'd8: s_reg = 7'b0000000;
            4'd9: s_reg = 7'b0010000; default: s_reg = 7'b1111111;
        endcase
    end
    assign seg = s_reg;

    reg [25:0] heartbeat_cnt;
    always @(posedge clk) heartbeat_cnt <= heartbeat_cnt + 1; 
    assign led[3:0] = state; assign led[4] = sys_start; assign led[5] = done_conv;
    assign led[6] = done_pool; assign led[7] = done_flat; assign led[8] = done_d1;
    assign led[9] = done_d2; assign led[10] = done_out; assign led[11] = done_arg;
    assign led[14:12] = 3'b0; assign led[15] = heartbeat_cnt[25]; 

endmodule