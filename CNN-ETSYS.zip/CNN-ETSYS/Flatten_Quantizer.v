module Flatten_Quantizer (
    input wire clk,
    input wire rst_n,
    input wire start,
    
    // RAM Okuma
    output reg [9:0] rd_addr,       
    input wire signed [31:0] data_in, 
    
    input wire [3:0] shift_val,
    
    // RAM Yazma
    output reg [7:0] data_out,
    output reg [9:0] addr_out,
    output reg we_out,
    output reg done
);
    reg [9:0] counter;
    reg [1:0] state;
    localparam S_IDLE = 0, S_READ = 1, S_PROCESS = 2, S_DONE = 3;

    // Logic variables
    reg signed [31:0] shifted_data;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out   <= 0;
            addr_out   <= 0;
            we_out     <= 0;
            done       <= 0;
            counter    <= 0;
            rd_addr    <= 0;
            state      <= S_IDLE;
        end else begin
            case (state)
                S_IDLE: begin
                    done <= 0;
                    we_out <= 0;
                    counter <= 0;
                    if (start) state <= S_READ;
                end

                S_READ: begin
                    rd_addr <= counter;
                    we_out <= 0; 
                    state <= S_PROCESS;
                end

                S_PROCESS: begin
                    // 1. Shift
                    shifted_data = data_in >>> shift_val;
                    
                    // 2. Clamp (Saturate to 0-127)
                    if (shifted_data > 32'sd127) 
                        data_out <= 8'd127;
                    else if (shifted_data < 32'sd0) 
                        data_out <= 8'd0;
                    else
                        data_out <= shifted_data[7:0];
                        
                    // 3. Flatten
                    addr_out <= counter;
                    we_out <= 1;

                    if (counter == 675) 
                        state <= S_DONE;
                    else begin
                        counter <= counter + 1;
                        state <= S_READ;
                    end
                end

                S_DONE: begin
                    we_out <= 0;
                    done <= 1;
                    state <= S_IDLE;
                end
            endcase
        end
    end
endmodule //yenile