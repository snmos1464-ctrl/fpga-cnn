module Argmax (
    input  wire        clk,
    input  wire        rst,
    input  wire        start,
    output reg  [3:0]  rd_addr,
    input  wire signed [31:0] rd_data,
    output reg  [3:0]  result,
    output reg         done
);
    reg [3:0] cnt;
    reg signed [31:0] max_val;
    reg [1:0] state;

    always @(posedge clk or posedge rst) begin
        if (rst) begin state <= 0; done <= 0; result <= 0; end
        else begin
            case (state)
                0: if (start) begin cnt <= 0; max_val <= 32'sh80000000; done <= 0; state <= 1; end
                1: begin rd_addr <= cnt; state <= 2; end
                2: begin 
                    if (rd_data > max_val) begin max_val <= rd_data; result <= cnt; end
                    if (cnt == 9) begin done <= 1; state <= 0; end
                    else begin cnt <= cnt + 1; state <= 1; end
                end
            endcase
        end
    end
endmodule